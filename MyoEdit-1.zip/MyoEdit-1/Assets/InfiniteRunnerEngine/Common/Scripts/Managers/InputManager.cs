using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using MoreMountains.Tools;

using LockingPolicy = Thalmic.Myo.LockingPolicy;
using Pose = Thalmic.Myo.Pose;
using UnlockType = Thalmic.Myo.UnlockType;
using VibrationType = Thalmic.Myo.VibrationType;

namespace MoreMountains.InfiniteRunnerEngine
{	
	/// <summary>
	/// This persistent singleton handles the inputs and sends commands to the player
	/// </summary>
	public class InputManager : MonoBehaviour
	{

		private GameObject myo; // root object
		private ThalmicMyo thalmicMyo ;
		private Pose _lastPose = Pose.Unknown;
		[HideInInspector]public int myoIntCheck = 0;
		public Vector2 YRangeGyroscope; // x = min , y = max
		private bool isWave = false;
		private bool updateReference = false;

		private Quaternion _antiYaw = Quaternion.identity;
		private float _referenceRoll = 0.0f;
		private float RoznicaKatow = 0f;

	


		// singleton pattern
		static public InputManager Instance { get { return _instance; } }
		static protected InputManager _instance;
		public void Awake()
		{
			_instance = this;

		}

		public void StartGame()
		{
			myo = GameObject.Find ("Hub - 1 Myo").transform.FindChild("Myo").gameObject;
			thalmicMyo = myo.GetComponent<ThalmicMyo> ();
		}

	    /// <summary>
	    /// Every frame, we get the various inputs and process them
	    /// </summary>
	    protected virtual void Update()
		{
	        HandleKeyboard();         
	    }

		/// <summary>
		/// Called at each Update(), it checks for various key presses
		/// </summary>

		//

//	void Update()
//		{
//			//thalmicMyo = myo.GetComponent<ThalmicMyo> (); // original code
//
//			//if (Speed != 0) 
//			//{
//			//    UpdateGUI(); // such as update time , score , life etc.
//			//}
//
//			updateReference = false;
//
//			if (thalmicMyo.pose != _lastPose) 
//			{
//				_lastPose = thalmicMyo.pose;
//
//				if (thalmicMyo.pose == Pose.FingersSpread) 
//				{
//					updateReference = true;
//					ExtendUnlockAndNotifyUserAction(thalmicMyo);
//				}
//
//				if(thalmicMyo.pose == Pose.WaveIn) // character will translate (Lerp) to Left
//				{
//					//Debug.Log("Left");
//
//					/*if((laneIndex-1) >= 0)
//					{
//						laneIndex--;
//					}*/
//				}
//
//				if(thalmicMyo.pose == Pose.WaveOut) // character will translate (Lerp) to Right
//				{
//					//Debug.Log("Right");
//
//				/*	if((laneIndex+1) <= (laneObjects.Length-1))
//					{
//						laneIndex++;
//					}*/
//				}
//
//				if(thalmicMyo.pose == Pose.Fist) // character will Jump
//				{
//					//Debug.Log("Jump");
//				}
//
//				if(thalmicMyo.pose == Pose.DoubleTap) // character will translate (Lerp) to Right
//				{
//					//Debug.Log("Increase Speed");
//				//	isIncreaseSpeed = !isIncreaseSpeed;
//				}
//			}
//
//			if (Input.GetKeyDown ("r")) {
//				updateReference = true;
//			}
//
//			if (updateReference) 
//			{
//
//				_antiYaw = Quaternion.FromToRotation (
//					new Vector3 (myo.transform.forward.x, 0, myo.transform.forward.z),
//					new Vector3 (0, 0, 1)
//				);
//
//				/*
//				Vector3 referenceZeroRoll = computeZeroRollVector (myo.transform.forward);
//				_referenceRoll = rollFromZero (referenceZeroRoll, myo.transform.forward, myo.transform.up);*/
//			}
//		}
			

	    protected virtual void HandleKeyboard()
		{
			
			if (Input.GetButtonDown("Pause")) { PauseButtonDown(); }
			if (Input.GetButtonUp("Pause")) { PauseButtonUp(); }
			if (Input.GetButton("Pause")) { PauseButtonPressed(); }

			if (Input.GetButtonDown("MainAction")) { MainActionButtonDown(); }
			if (Input.GetButtonUp("MainAction")) { MainActionButtonUp(); }
			if (Input.GetButton("MainAction")) { MainActionButtonPressed(); }
			
			if (Input.GetButtonDown("Left")) { LeftButtonDown(); }
			if (Input.GetButtonUp("Left")) { LeftButtonUp(); }
			if (Input.GetButton("Left")) { LeftButtonPressed(); }
			
			if (Input.GetButtonDown("Right")) { RightButtonDown(); }
			if (Input.GetButtonUp("Right")) { RightButtonUp(); }
			if (Input.GetButton("Right")) { RightButtonPressed(); }
			
			if (Input.GetButtonDown("Up")) { UpButtonDown(); }
			if (Input.GetButtonUp("Up")) { UpButtonUp(); }
			if (Input.GetButton("Up")) { UpButtonPressed(); }
			
			if (Input.GetButtonDown("Down")) { DownButtonDown(); }
			if (Input.GetButtonUp("Down")) { DownButtonUp(); }
			if (Input.GetButton("Down")) { DownButtonPressed(); }

	    }
		
		/// PAUSE BUTTON ----------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Triggered once when the pause button is pressed down
		/// </summary>

		public virtual void PauseButtonDown() { GameManager.Instance.Pause(); }
		/// <summary>
		/// Triggered once when the pause button is released
		/// </summary>

		public virtual void PauseButtonUp() {}
		/// <summary>
		/// Triggered while the pause button is being pressed
		/// </summary>

		public virtual void PauseButtonPressed() {}


		/// MAIN ACTION BUTTON ----------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Triggered once when the main action button is pressed down
		/// </summary>
	    public virtual void MainActionButtonDown()
	    {
	        if (LevelManager.Instance.ControlScheme==LevelManager.Controls.SingleButton)
	        {
	            if (GameManager.Instance.Status == GameManager.GameStatus.GameOver)
	            {
	                LevelManager.Instance.GameOverAction();
	                return;
	            }
	            if (GameManager.Instance.Status == GameManager.GameStatus.LifeLost)
	            {
	                LevelManager.Instance.LifeLostAction();
	                return;
	            }
	        }
	        
	        for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].MainActionStart();
	        }
	    }

		/// <summary>
		/// Triggered once when the main action button button is released
		/// </summary>
	    public virtual void MainActionButtonUp()
	    {    	
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].MainActionEnd();
	        }
		}
		
		/// <summary>
		/// Triggered while the main action button button is being pressed
		/// </summary>

		public virtual void MainActionButtonPressed() 
		{
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].MainActionOngoing();
	        }
		}



		/// LEFT BUTTON ----------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Triggered once when the left button is pressed down
		/// </summary>
	    public virtual void LeftButtonDown()
	    {
	        if (LevelManager.Instance.ControlScheme == LevelManager.Controls.LeftRight)
	        {
	            if (GameManager.Instance.Status == GameManager.GameStatus.GameOver)
	            {
	                LevelManager.Instance.GameOverAction();
	                return;
	            }
	            if (GameManager.Instance.Status == GameManager.GameStatus.LifeLost)
	            {
	                LevelManager.Instance.LifeLostAction();
	                return;
	            }
	        }

			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].LeftStart();
	        }
	    }

		/// <summary>
		/// Triggered once when the left button is released
		/// </summary>
	    public virtual void LeftButtonUp()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].LeftEnd();
	        }
	    }

		/// <summary>
		/// Triggered while the left button is being pressed
		/// </summary>
	    public virtual void LeftButtonPressed()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].LeftOngoing();
	        }
	    }


		/// RIGHT BUTTON ----------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Triggered once when the right button is pressed down
		/// </summary>
	    public virtual void RightButtonDown()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].RightStart();
	        }
	    }

		/// <summary>
		/// Triggered once when the right button is released
		/// </summary>
	    public virtual void RightButtonUp()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].RightEnd();
	        }
	    }

		/// <summary>
		/// Triggered while the right button is being pressed
		/// </summary>
	    public virtual void RightButtonPressed()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].RightOngoing();
	        }
	    }



		/// DOWN BUTTON ----------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Triggered once when the down button is pressed down
		/// </summary>
	    public virtual void DownButtonDown()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].DownStart();
	        }
	    }

		/// <summary>
		/// Triggered once when the down button is released
		/// </summary>
	    public virtual void DownButtonUp()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].DownEnd();
	        }
	    }

		/// <summary>
		/// Triggered while the down button is being pressed
		/// </summary>
	    public virtual void DownButtonPressed()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].DownOngoing();
	        }
	    }



		/// UP BUTTON ----------------------------------------------------------------------------------------------------------------
		/// <summary>
		/// Triggered once when the up button is pressed down
		/// </summary>
	    public virtual void UpButtonDown()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].UpStart();
	        }
	    }

		/// <summary>
		/// Triggered once when the up button is released
		/// </summary>
	    public virtual void UpButtonUp()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].UpEnd();
	        }
	    }

		/// <summary>
		/// Triggered while the up button is being pressed
		/// </summary>
	    public virtual void UpButtonPressed()
	    {
			for (int i = 0; i < LevelManager.Instance.CurrentPlayableCharacters.Count; ++i)
	        {
				LevelManager.Instance.CurrentPlayableCharacters[i].UpOngoing();
	        }
	    }
		/// <summary>
		/// Exten myo Lock action
		/// </summary>
		/// <param name="myo">Myo.</param>
		void ExtendUnlockAndNotifyUserAction (ThalmicMyo myo)
		{
			ThalmicHub hub = ThalmicHub.instance;

			if (hub.lockingPolicy == LockingPolicy.Standard) {
				myo.Unlock (UnlockType.Timed);
			}

			myo.NotifyUserAction ();
		}


	}
}